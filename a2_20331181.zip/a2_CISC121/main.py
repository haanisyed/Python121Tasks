'''
CISC-121 2023W
Name: Haani Syed
Student Number: 20331181
Email: 21ahs7@queensu.ca
Date: 2023-02-01
I confirm that this assignment solution is my own work and conforms to Queen’s standards of Academic Integrity
'''
#each question's answer is saved in it's own file (functions.py, a2_q2, a2_q1, friendship.txt)

def friends_to_dictionary():
    '''
    purpose: function that is imported in a2q2 for reading txtfile content to dictionary. No parameters.
    :return: that_dict (dictionary)
    '''
    opening = open("friendship.txt", "r")
    y = (opening.readlines())
    list = []
    r = 0
    for i in y:
        s = y[r].split()
        list.append(s)
        r += 1
    count = 0
    that_dict = dict()
    for i in list:
        if list[count][0] not in that_dict:
            that_dict.update({list[count][0]: list[count][1]})
        else:
            that_dict[list[count][0]] = [that_dict[list[count][0]], list[count][1]]
        count += 1
    return that_dict




