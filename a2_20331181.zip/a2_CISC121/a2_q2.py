'''
CISC-121 2023W
Name: Haani Syed
Student Number: 20331181
Email: 21ahs7@queensu.ca
Date: 2023-02-01
I confirm that this assignment solution is my own work and conforms to Queen’s standards of Academic Integrity
'''
#make an import once the 3 functions are running and place the 3 functions into the functions.py

from functions import friends_to_dictionary #imports friend_to_dictionary()
from functions import all_my_friends #imports all_my_friends()
from functions import friendship_degree #imports friendship_degree
def main():
    '''
    purpose: call to variables and functions that allow program to execute and run efficiently.
    parameters: none. Call to 3 functions(friendstodictionary, allmyfriends, friendship degree) in functions.py is made.
    :return: no specific return however it does call other functions which return.
    '''
    x = friends_to_dictionary()
    friend = 'Michael' #or any other name from the friendship.txt
    values = all_my_friends(friend)
    friendship_degree(x)
main()


